#include "bet.h"

int main() {
  return 0;
}
